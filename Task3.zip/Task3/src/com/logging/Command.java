package com.logging;

public interface Command {
    void execute(String message);
}

