package com.sis.interfaces;

public interface IEnrollmentManagement {
    void enrollStudentInCourse(int studentId, int courseId);
}

